[8]# -*- coding: utf-8 -*-

"""
/***************************************************************************
 InterfaceExperimentDockWidget
                                 A QGIS plugin
 try creating a functional interface for flood
                             -------------------
        begin                : 2015-12-04
        git sha              : $Format:%H$
        copyright            : (C) 2015 by fbot
        email                : f.j.bot@student.tudelft.nl
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

# Initialize Qt resources from file resources.py
from PyQt4 import QtGui, QtCore, uic
from qgis.core import *
from qgis.networkanalysis import *
from qgis.gui import *
import processing

# Initialize Qt resources from file resources.py
import resources

import os
import os.path
import random
import csv

from PyQt4 import QtGui, Qt, QtCore, QtWebKit
from PyQt4.QtWebKit import QWebPage, QWebView
from PyQt4.QtCore import QUrl
import sys

#to read excel-file
try:
    import xlrd
except ImportError, e:
    from .external import xlrd as xl
    print('excel import succeeded')
#other import for waterlevel-diagram function
import matplotlib as p
import matplotlib.pyplot as plt
#import xlrd
import datetime
import time
import matplotlib.dates as dt
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas

from . import utility_functions as uf

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'InterfaceExperimentModule_dockwidget_base.ui'))

class InterfaceExperimentDockWidget(QtGui.QDockWidget, FORM_CLASS):

    closingPlugin = QtCore.pyqtSignal()
    updateAttribute = QtCore.pyqtSignal(str)
    clickingPoint = QtCore.pyqtSignal(QgsPoint)



    def __init__(self, iface, parent=None):
        """Constructor."""
        super(InterfaceExperimentDockWidget, self).__init__(parent)
        # Set up the user interface from Designer.
        # After setupUI you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)

        # define globals
        self.iface = iface
        self.canvas = self.iface.mapCanvas()

        self.tabWidget.hide()

        # diagram
        #self.diagramLabel.setPixmap(QtGui.QPixmap(':icons/plot1.png'))

        # connect file to plugin
        self.openScenarioButton.clicked.connect(self.openScenario)
        self.fillOrigins()
        self.fillDestinations()
        self.originLayerBox.activated.connect(self.fillOrigins)
        self.destinationLayerBox.activated.connect(self.fillDestinations)

        # classification
        self.positionLabel.hide()
        self.positionButton.clicked.connect(self.enterLocation)
        self.clickingPoint.connect(self.addPointToLayer)
        self.clickingPoint.connect(self.getOrigin)
        self.clickingPoint.connect(self.showWarning)
        self.emitPoint = QgsMapToolEmitPoint(self.canvas)
        self.emitPoint.canvasClicked.connect(self.getPoint)

        #self.waterHeightBox.valueChanged.connect(self.waterHeightChanged)
        self.waterComboBox.activated.connect(self.showWarning)

       # routing
        self.graph = QgsGraph()
        self.tied_points = []
        self.shortestRouteButton.clicked.connect(self.calculateRoute)
        self.deleteRoutesButton.clicked.connect(self.deleteRoutes)
        self.originBox.activated.connect(self.getNewOrigin)
        #self.destinationBox.activated.connect(self.updateDestination)
        self.networkLabel.hide()
        self.shortestRouteLabel.hide()
        self.shortestRouteButton.hide()
        self.deleteRoutesButton.hide()

        # Save Image
        self.saveMapButton.clicked.connect(self.saveMap)
        self.saveMapPathButton.clicked.connect(self.selectFile)
        self.reportLabel.hide()

        #gif
        #movie = QtGui.QMovie(':icons/radar1.gif')
        #self.radarLabel.setMovie(movie)
        #movie.start()

        #############
        self.updateAttribute.connect(self.createWaterLevelDiagram)
        # add matplotlib Figure to chartFrame
        self.chart_figure = Figure()
        self.chart_subplot_line = self.chart_figure.add_subplot(222)
        #self.chart_figure.tight_layout()
        self.chart_canvas = FigureCanvas(self.chart_figure)
        #self.chartLayout.addWidget(self.chart_canvas)

        self.clickingPoint.connect(self.createWaterLevelDiagram)

        #website gif
        self.radarLabel.load(QUrl('http://www.buienradar.nl/image/?type=forecast3hourszozw&fn=buienradarnl-1x1-ani700-verwachting-3uur.gif'))
        self.radarLabel.show()

        #website gif
        #self.wikiweb.load(QUrl('https://github.com/efrancesp/GEO1005_ArnhemFlooding/wiki'))
        #self.wikiweb.show()

        #self.WebAction.OpenLinkInNewWindow(QUrl('https://github.com/efrancesp/GEO1005_ArnhemFlooding/wiki'))
        self.getwiki.clicked.connect(self.openWiki)
        self.radarButton.clicked.connect(self.openRadar)


    def closeEvent(self, event):
        self.deleteRoutes()

        self.reportLabel.hide()
        self.tabWidget.hide()
        self.saveMapPathEdit.clear()

        flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
        flood_layer.setSubsetString("id < 0")
        risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
        risk_layer.setSubsetString("id < 0")

        self.closingPlugin.emit()
        event.accept()

### Data Functions ###

    # General Functions (these seem like we need them, not sure though).
    def openScenario(self,filename=""):
        scenario_open = False
        scenario_file = os.path.join('/InterfaceExperiment/Final Shapefiles','basemap.qgs')
        # check if file exists
        if os.path.isfile(scenario_file):
            self.iface.addProject(scenario_file)
            scenario_open = True
        else:
            last_dir = uf.getLastDir("InterfaceExperiment") # getLastDir(tool_name=''):
            new_file = QtGui.QFileDialog.getOpenFileName(self, "", last_dir, "(*.qgs)")
            if new_file:
                self.iface.addProject(new_file)
                scenario_open = True
        if scenario_open:
            self.fillDestinations()
            #self.fillComboBox(self.originBox,"layername", "fieldname")
            # here i want to give the option to either click starting point or select POI
            # and to either travel to POI or Escape_Point

    def saveScenario(self):
        self.iface.actionSaveProject()

### Interface Specifications ###

    # saving the current screen
    def selectFile(self):
        self.reportLabel.hide()
        last_dir = uf.getLastDir("InterfaceExperiment")
        path = QtGui.QFileDialog.getSaveFileName(self, "Save map file", last_dir, "PNG (*.png)")
        if path.strip()!="":
            path = unicode(path)
            uf.setLastDir(path,"InterfaceExperiment")
            self.saveMapPathEdit.setText(path)

    def saveMap(self):
        filename = self.saveMapPathEdit.text()
        if filename != '':
            self.canvas.saveAsImage(filename,None,"PNG")
            self.reportLabel.show()

    # point clicking
    def enterLocation(self):
        # remember currently selected tool
        self.userTool = self.canvas.mapTool()
        # activate location capture tool
        self.canvas.setMapTool(self.emitPoint)
        self.positionLabel.show()

    def getPoint(self, mapPoint, mouseButton):
        # change tool so you don't get more than one POI
        self.canvas.unsetMapTool(self.emitPoint)
        self.canvas.setMapTool(self.userTool)
        self.positionLabel.hide()
        #Get the click
        if mapPoint:
            # here do something with the point
            self.clickingPoint.emit(mapPoint)

### route functions ###

    def fillOrigins(self):
        origin_layer_name = self.originLayerBox.currentText()
        origin_layer = uf.getLegendLayerByName(self.iface,origin_layer_name)
        origin_field = uf.getFieldValues(origin_layer,"Name")
        self.originBox.clear()
        self.originBox.addItems(origin_field[0])

    def fillDestinations(self):
        dest_layer_name = self.destinationLayerBox.currentText()
        dest_layer = uf.getLegendLayerByName(self.iface,dest_layer_name)
        dest_field = uf.getFieldValues(dest_layer,"Name")
        self.destinationBox.clear()
        self.destinationBox.addItems(dest_field[0])

    def getNetwork(self):
        roads_layer = uf.getLegendLayerByName(self.iface, "Roads")
        if roads_layer:
            # see if there is an obstacles layer to subtract roads from the network
            obstacles_layer = uf.getLegendLayerByName(self.iface, "Obstacles")
            if obstacles_layer:
                # retreive roads outside obstacles (inside = False)
                features = uf.getFeaturesByIntersection(roads_layer, obstacles_layer, False)
                # add these roads to a new temporary layer
                road_network = uf.createTempLayer("temp_network", 'LINESTRING', roads_layer.crs().postgisSrid(),[],[])
                road_network.dataProvider().addFeatures(features)
                network_layer = uf.getLegendLayerByName(self.iface, "temp_network")
                uf.loadTempLayer(network_layer)
            else:
                road_network = roads_layer
            return road_network
        else:
            return

    def getOrigin(self,point):
        if point:
            self.buildNetwork(point)
        else:
            self.buildNetwork()

    def getNewOrigin(self):
        self.buildNetwork()

    def updateDestination(self):
        self.buildNetwork()

    def getDestination(self,destination=True):
        if destination:
            destination_layer_name = self.destinationLayerBox.currentText()
            destination_name = self.destinationBox.currentText()
        else:
            destination_layer_name = self.originLayerBox.currentText()
            destination_name = self.originBox.currentText()

        destination_layer = uf.getLegendLayerByName(self.iface, destination_layer_name)
        destination_field = uf.getFieldValues(destination_layer,"Name")
        lat = uf.getFieldValues(destination_layer,"LAT")
        lon = uf.getFieldValues(destination_layer,"LON")

        for i in range(len(destination_field[0])):
            if destination_field[0][i] == destination_name:
                coords = zip(lat[0],lon[0])[i]
                point = QgsPoint(coords[0],coords[1])
                return point

    def buildNetwork(self,point=None): # + origin?
        self.network_layer = self.getNetwork()
        if self.network_layer:
            # get the points to be used as origin and destination -- This needs adaptation to our situation
            if point:
                origin_coords = point
            else:
                origin_coords = self.getDestination(False)
            #origin_coords = origin
            destination_coords = self.getDestination(True)
            source_points = [origin_coords, destination_coords]
            if len(source_points) > 1:
                self.graph, self.tied_points = uf.makeUndirectedGraph(self.network_layer, source_points)
                if self.graph and self.tied_points:
                    self.networkLabel.show()
                    self.shortestRouteButton.show()
                else:
                    self.shortestRouteLabel.hide()
                    self.networkLabel.hide()
                    self.shortestRouteButton.hide()
        return

    def calculateRoute(self):
        # origin and destination must be in the set of tied_points
        options = len(self.tied_points)
        if options > 1:
            # origin and destination are given as an index in the tied_points list
            origin = 0
            destination = 1
            # calculate the shortest path for the given origin and destination
            path = uf.calculateRouteDijkstra(self.graph, self.tied_points, origin, destination)
            # store the route results in temporary layer called "Routes"
            routes_layer = uf.getLegendLayerByName(self.iface, "Routes")
            # create one if it doesn't exist
            if not routes_layer:
                attr = ["id"]
                types = [QtCore.QVariant.String]
                routes_layer = uf.createTempLayer("Routes", "LINESTRING", self.network_layer.crs().postgisSrid(), attr, types)
                uf.loadTempLayer(routes_layer)
                routes_layer.setLayerName("Routes")
            # insert route line
            provider = routes_layer.dataProvider()
            routes_layer.startEditing()
            #provider.addAttributes([QgsField("ids", QtCore.QVariant.String)])
            line = QgsFeature()
            line.setGeometry(QgsGeometry.fromPolyline(path))
            line.setAttributes([1])
            provider.addFeatures([line])
            routes_layer.commitChanges()
            provider.updateExtents() # or routes_layer
            #self.canvas.refresh()
            QgsMapLayerRegistry.instance().addMapLayer(routes_layer)
            self.shortestRouteLabel.show()
            self.deleteRoutesButton.show()


    def deleteRoutes(self):
        routes_layer = uf.getLegendLayerByName(self.iface, "Routes")
        if routes_layer:
            ids = uf.getAllFeatureIds(routes_layer)
            routes_layer.startEditing()
            for id in ids:
                routes_layer.deleteFeature(id)
            routes_layer.commitChanges()
            routes_layer.updateFields()
        self.shortestRouteLabel.hide()
        self.networkLabel.hide()
        self.shortestRouteButton.hide()



### Warning Messages / Classification ###

    def getLocalElevation(self,point):
        if point:
            #return 40
            polygon = None
            point_geom = QgsGeometry.fromPoint(point)
            base_layer = uf.getLegendLayerByName(self.iface,"Elevation")
            # retrieve base layer objects
            features = base_layer.getFeatures()
            for feat in features:
                base_geom = feat.geometry()
                if base_geom.intersects(point_geom):
                    polygon = feat
                    idx = feat.id()
                    break
            elevation_layer = uf.getLegendLayerByName(self.iface, "Elevation")
            field_Elev_m = uf.getFieldValues(elevation_layer,"Elev_m")
            return field_Elev_m[0][idx]

        else:
            print "connect didnt work (getlocalelevation)"

    def addPointToLayer(self, point):
        # Get layer to edit and variables
        layer = uf.getLegendLayerByName(self.iface, "CrowdSource")
        coord_x = point[0]
        coord_y = point[1]
        water_height = self.waterHeightBox.value()
        local_elev = self.getLocalElevation(point)

        # Edit attributes of layer
        provider = layer.dataProvider()
        layer.startEditing()
        point_new = QgsFeature()
        point_new.setGeometry(QgsGeometry.fromPoint(point))
        point_new.setAttributes(["Clicked_Point", water_height, coord_x, coord_y, local_elev])
        provider.addFeatures([point_new])
        layer.commitChanges()
        provider.updateExtents() # or routes_layer
        QgsMapLayerRegistry.instance().addMapLayer(layer)

        self.tabWidget.show()

    def createAttWaterHeight(self,local_elev,WaterLevel):
        # Call and define layers
        flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
        risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")

        # Define field attributes
        field_Elev_m = uf.getFieldValues(flood_layer,"Elev_local")

        # Create new water heights list
        WaterHeight = []
        for i in range(len(field_Elev_m[0])):
            new_wht = WaterLevel + local_elev
            WaterHeight.append(new_wht)

        # Create new local elevation list
        LocalElev = []
        for j in range(len(field_Elev_m[0])):
            new_lelev = local_elev
            LocalElev.append(new_lelev)

        # Update FLOOD attribute table
        pr1 = flood_layer.dataProvider()
        ids1 = uf.getAllFeatureIds(flood_layer)
        ids_field1 = zip(ids1, WaterHeight)
        ids_field12 = zip(ids1, LocalElev)
        attr_map1 = {}
        for id1,value1 in ids_field1:
            attr_map1[id1] = {2: value1}
        pr1.changeAttributeValues(attr_map1)
        for id1,value1 in ids_field12:
            attr_map1[id1] = {3: value1}
        pr1.changeAttributeValues(attr_map1)

        # Update RISK attribute table
        pr2 = risk_layer.dataProvider()
        ids2 = uf.getAllFeatureIds(risk_layer)
        ids_field2 = zip(ids2, WaterHeight)
        ids_field22 = zip(ids2, LocalElev)
        attr_map2 = {}
        for id2,value2 in ids_field2:
            attr_map2[id2] = {2: value2}
        pr2.changeAttributeValues(attr_map2)
        for id2,value2 in ids_field22:
            attr_map2[id2] = {3: value2}
        pr2.changeAttributeValues(attr_map2)


    def showWarning(self):

        # Extract user defined water level from location
        crowds_layer = uf.getLegendLayerByName(self.iface, "CrowdSource")
        wl_field = uf.getFieldValues(crowds_layer, "WaterLevel")
        ptx_field = uf.getFieldValues(crowds_layer, "Coord_x")
        pty_field = uf.getFieldValues(crowds_layer, "Coord_y")
        local_elev_field = uf.getFieldValues(crowds_layer, "Local_Elev")
        WaterLevel = wl_field[0][-1]
        proj_WaterLevel = self.waterComboBox.currentText()
        local_elev_opt = local_elev_field[0][-1]

        local_elev = local_elev_opt * 100

        # Clear all filters
        flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
        flood_layer.setSubsetString("")
        risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
        risk_layer.setSubsetString("")

        # Calculate flooding depth at user location

        if proj_WaterLevel == "...": # move to after get location is clicked!
            self.createAttWaterHeight(local_elev,WaterLevel)
            if WaterLevel > 1 and WaterLevel <= 20:
                self.iface.messageBar().pushMessage("Info","Store important items in a high and dry place. "
                                                       "Protect your possessions from damage (sandbags). "
                                                       "Cars are able to move at a walking pace.", level=0, duration=20)
                self.createAttWaterHeight(local_elev,WaterLevel)
                flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
                flood_layer.setSubsetString("WaterHt - Elev_cm > 100")
                risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
                risk_layer.setSubsetString("WaterHt - Elev_cm > 20")
            elif WaterLevel > 20 and WaterLevel <= 50:
                self.iface.messageBar().pushMessage("Warning","Ensure that you, your family, and important articles are safe. "
                                                       "People needing help can still be reached on foot. "
                                                       "Help others.", level=1, duration=20)
                self.createAttWaterHeight(local_elev,WaterLevel)
                flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
                flood_layer.setSubsetString("WaterHt - Elev_cm > 100")
                risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
                risk_layer.setSubsetString("WaterHt - Elev_cm > 20")
            elif WaterLevel > 50 and WaterLevel <= 80:
                self.iface.messageBar().pushMessage("Warning","Military vehicles can still move. "
                                                          "You can still be reached by emergency responders. "
                                                          "Ensure that you and your family are safe. "
                                                          "See where you can offer help in a safe place.", level=1, duration=20)
                self.createAttWaterHeight(local_elev,WaterLevel)
                flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
                flood_layer.setSubsetString("WaterHt - Elev_cm > 100")
                risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
                risk_layer.setSubsetString("WaterHt - Elev_cm > 20")
            elif WaterLevel > 80 and WaterLevel <= 200:
                self.iface.messageBar().pushMessage("Warning","The first floor of your house is safe. "
                                                          "Ensure that you and your family are safe and keep a battery powered radio with you. "
                                                          "Listen to the disaster broadcasting station for emergency news.", level=1, duration=20)
                self.createAttWaterHeight(local_elev,WaterLevel)
                flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
                flood_layer.setSubsetString("WaterHt - Elev_cm > 100")
                risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
                risk_layer.setSubsetString("WaterHt - Elev_cm > 20")
            elif WaterLevel > 200 and WaterLevel < 500:
                self.iface.messageBar().pushMessage("CRITICAL", "EVACUATE NOW. READ THE FOLLOWING VERY CAREFULLY. "
                                                            "The second floor of your house is relatively safe. "
                                                            "Ensure that you and your family are safe and keep a battery powered radio with you. "
                                                            "Listen to the disaster broadcasting station for emergency news. "
                                                            "Ensure that you are near an exit or on the roof so that you can be rescued by the emergency services. "
                                                            "Hang a white sheet out of the window so that the emergency responders know you are still in the house. "
                                                            "DO NOT ATTEMPT TO INVESTIGATE MANNERS FOR YOURSELF.", level=2)
                self.createAttWaterHeight(local_elev,WaterLevel)
                flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
                flood_layer.setSubsetString("WaterHt - Elev_cm > 100")
                risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
                risk_layer.setSubsetString("WaterHt - Elev_cm > 20")
            elif WaterLevel == 500:
                self.iface.messageBar().pushMessage("CRITICAL", "EVACUATE NOW. READ THE FOLLOWING VERY CAREFULLY. "
                                                            "The second floor of your house is relatively safe. "
                                                            "Ensure that you and your family are safe and keep a battery powered radio with you. "
                                                            "Listen to the disaster broadcasting station for emergency news. "
                                                            "Ensure that you are near an exit or on the roof so that you can be rescued by the emergency services. "
                                                            "Hang a white sheet out of the window so that the emergency responders know you are still in the house. "
                                                            "DO NOT ATTEMPT TO INVESTIGATE MANNERS FOR YOURSELF.", level=2)
                self.createAttWaterHeight(local_elev,WaterLevel)
                flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
                flood_layer.setSubsetString("WaterHt - Elev_cm > 100")
                risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
                risk_layer.setSubsetString("")
            else:
                self.iface.messageBar().pushMessage("Info","You are safe.", level=3, duration=20)
                self.createAttWaterHeight(local_elev,WaterLevel)
                flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
                flood_layer.setSubsetString("id < 0")
                risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
                risk_layer.setSubsetString("id < 0")
        elif proj_WaterLevel == "1 - 20 cm":
            self.iface.messageBar().pushMessage("Info","Store important items in a high and dry place. "
                                                       "Protect your possessions from damage (sandbags). "
                                                       "Cars are able to move at a walking pace.", level=0, duration=20)
            self.createAttWaterHeight(local_elev,20)
            flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
            flood_layer.setSubsetString("WaterHt - Elev_cm > 100")
            risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
            risk_layer.setSubsetString("WaterHt - Elev_cm > 20")
        elif proj_WaterLevel == "20 - 50 cm":
            self.iface.messageBar().pushMessage("Warning","Ensure that you, your family, and important articles are safe. "
                                                       "People needing help can still be reached on foot. "
                                                       "Help others.", level=1, duration=20)
            self.createAttWaterHeight(local_elev,50)
            flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
            flood_layer.setSubsetString("WaterHt - Elev_cm > 100")
            risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
            risk_layer.setSubsetString("WaterHt - Elev_cm > 20")
        elif proj_WaterLevel == "50 - 80 cm":
            self.iface.messageBar().pushMessage("Warning","Military vehicles can still move. "
                                                          "You can still be reached by emergency responders. "
                                                          "Ensure that you and your family are safe. "
                                                          "See where you can offer help in a safe place.", level=1, duration=20)
            self.createAttWaterHeight(local_elev,80)
            flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
            flood_layer.setSubsetString("WaterHt - Elev_cm > 100")
            risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
            risk_layer.setSubsetString("WaterHt - Elev_cm > 20")
        elif proj_WaterLevel == "80 cm - 2 m":
            self.iface.messageBar().pushMessage("Warning","The first floor of your house is safe. "
                                                          "Ensure that you and your family are safe and keep a battery powered radio with you. "
                                                          "Listen to the disaster broadcasting station for emergency news.", level=1, duration=20)
            self.createAttWaterHeight(local_elev,200)
            flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
            flood_layer.setSubsetString("WaterHt - Elev_cm > 100")
            risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
            risk_layer.setSubsetString("WaterHt - Elev_cm > 20")
        elif proj_WaterLevel == "2 - 5 m":
            self.iface.messageBar().pushMessage("CRITICAL", "EVACUATE NOW. READ THE FOLLOWING VERY CAREFULLY. "
                                                            "The second floor of your house is relatively safe. "
                                                            "Ensure that you and your family are safe and keep a battery powered radio with you. "
                                                            "Listen to the disaster broadcasting station for emergency news. "
                                                            "Ensure that you are near an exit or on the roof so that you can be rescued by the emergency services. "
                                                            "Hang a white sheet out of the window so that the emergency responders know you are still in the house. "
                                                            "DO NOT ATTEMPT TO INVESTIGATE MANNERS FOR YOURSELF.", level=2)
            self.createAttWaterHeight(local_elev,500)
            flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
            flood_layer.setSubsetString("WaterHt - Elev_cm > 100")
            risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
            risk_layer.setSubsetString("WaterHt - Elev_cm > 20")
        elif proj_WaterLevel == "Greater than 5 m":
            self.iface.messageBar().pushMessage("CRITICAL", "EVACUATE NOW. READ THE FOLLOWING VERY CAREFULLY. "
                                                            "The second floor of your house is relatively safe. "
                                                            "Ensure that you and your family are safe and keep a battery powered radio with you. "
                                                            "Listen to the disaster broadcasting station for emergency news. "
                                                            "Ensure that you are near an exit or on the roof so that you can be rescued by the emergency services. "
                                                            "Hang a white sheet out of the window so that the emergency responders know you are still in the house. "
                                                            "DO NOT ATTEMPT TO INVESTIGATE MANNERS FOR YOURSELF.", level=2)
            self.createAttWaterHeight(local_elev,1000)
            flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
            flood_layer.setSubsetString("WaterHt - Elev_cm > 100")
            risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
            risk_layer.setSubsetString("")
        else:
            self.iface.messageBar().pushMessage("Info","You are safe.", level=3, duration=20)
            self.createAttWaterHeight(local_elev,0)
            flood_layer = uf.getLegendLayerByName(self.iface, "FloodedArea")
            flood_layer.setSubsetString("id < 0")
            risk_layer = uf.getLegendLayerByName(self.iface, "RiskArea")
            risk_layer.setSubsetString("id < 0")


    #waterleveldiagram  change h!!!
    def createWaterLevelDiagram(self, point):

        crowds_layer = uf.getLegendLayerByName(self.iface, "CrowdSource")
        wl_field = uf.getFieldValues(crowds_layer,"WaterLevel")
        h = wl_field[0][-1]
        self.chart_subplot_line.cla()

        l = self.getLocalElevation(point)

        #list with chosen location-height
        location_heigth = [l, l, l, l, l, l]

        filename = "%s/weather_data.xlsx" % QgsProject.instance().homePath()

        wb = xl.open_workbook(filename, "rb")
        sh = wb.sheet_by_index(0)
        rows = []
        days = []
        rain = []
        for row_number in xrange(sh.nrows):
            rows.append(sh.row_values(row_number))
        for row in rows[50:56]:
            for m in range(0,22,145):
                s = row[m].split(' ')
                days.append(s[1])
                rain.append(s[7])
        print "rain", rain

        rain_mm=[]
        for i in rain:
            if len(i)== 5:
                s = '0.0'+i[2]               #convert mm to m
                rain_mm.append(float(s))
            if len(i)== 6:
                s = '0.0'+i[2:4]
                rain_mm.append(float(s))
            if len(i)== 3:
                s = '0.0'+i[0]
                rain_mm.append(float(s))

        date=[]
        for i in days:
            d = int(i[0:2])
            m = int(i[3:5])
            y = int(i[6:10])
            d = datetime.date(y,m,d)
            date.append(d)
        dates = dt.date2num(date)
        print "dates", dates

        #sum combined water-level for six days
        water = [h+l+rain_mm[0], h+l+rain_mm[1],h+l+rain_mm[2],
                 h+l+rain_mm[3],h+l+rain_mm[4], h+l+rain_mm[5]]
        print "water", water

        ###
        #plotting data in diagram
        fig = plt.figure()
        ax = fig.add_subplot(111)
        plt.plot_date(dates, water, 'b-',linewidth=3)
        plt.plot_date(dates, location_heigth, 'm--',linewidth=5)

        #plt.fill(dates, water, color='blue')
        fig.autofmt_xdate()
        y_formatter = p.ticker.ScalarFormatter(useOffset=False)
        ax.yaxis.set_major_formatter(y_formatter)


        #other labels and legend
        plt.xlabel('date')
        plt.ylabel('heigth in m')
        plt.legend(('water-level + rainfall','height of chosen location'),
                   bbox_to_anchor=(0., 1.02, 1., .102), loc=3,
                   ncol=2, mode="expand", borderaxespad=0.)

        # show grid lines
        ax = plt.axes()
        ax.grid(True)

        #smaller picture size


        # show plot window
        plt.show()
        ###

        self.chart_subplot_line.plot(dates, water, 'r.-')

        # draw all the plots
        self.chart_canvas.draw()

    def openWiki(self):
        #self.app = QtGui.QApplication(sys.argv)
        #self.app.setApplicationName('MyWindow')
        self.main = MyWindow()
        self.main.show()
        self.main.load(QtCore.QUrl("https://github.com/efrancesp/GEO1005_ArnhemFlooding/wiki"))
        #sys.exit(app.exec_())

    def openRadar(self):
        #self.app = QtGui.QApplication(sys.argv)
        #self.app.setApplicationName('MyWindow')
        self.main = MyWindow()
        self.main.show()
        self.main.load(QtCore.QUrl("http://www.buienradar.nl/verwachting-3-uur"))
        #sys.exit(app.exec_())

class MyPage(QtWebKit.QWebPage):
    def __init__(self, parent=None):
        super(MyPage, self).__init__(parent)

    def triggerAction(self, action, checked=False):
        if action == QtWebKit.QWebPage.OpenLinkInNewWindow:
            self.createWindow(QtWebKit.QWebPage.WebBrowserWindow)
        return super(MyPage, self).triggerAction(action, checked)


class MyWindow(QtWebKit.QWebView):
    def __init__(self, parent=None):
        super(MyWindow, self).__init__(parent)
        self.myPage = MyPage(self)
        self.setPage(self.myPage)

    def createWindow(self, windowType):
        if windowType == QtWebKit.QWebPage.WebBrowserWindow:
            self.webView = MyWindow()
            self.webView.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
            return self.webView
        return super(MyWindow, self).createWindow(windowType)